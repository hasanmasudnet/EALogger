# alanlogger

UTC-first logging with optional JSON formatting and username context.

## Usage

```python
from alanlogger import get_logger
logger = get_logger(__name__, app_name="myapp", use_json=True, username="ian")
logger.info("Hello")
