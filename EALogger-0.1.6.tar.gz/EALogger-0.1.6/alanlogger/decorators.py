# decorators.py
import functools
from .logging_setup import get_logger, get_default_app_name

__all__ = ["log_entry_exit"]

# def log_entry_exit(func=None, *, app_name=None, use_json=True):
def log_entry_exit(func=None, *, app_name=None, use_json=True):
    """
    Decorator to log entry, exit, and exceptions for a function.
    If app_name is not provided, falls back to global default (set via set_default_app_name).
    """

    def decorator(inner_func):
        logger = get_logger(
            inner_func.__module__,
            app_name=app_name or get_default_app_name(),
            use_json=use_json,
        )

        @functools.wraps(inner_func)
        def wrapper(*args, **kwargs):
            logger.debug("Entering %s with args=%r kwargs=%r", inner_func.__name__, args, kwargs)
            try:
                result = inner_func(*args, **kwargs)
                return result
            except Exception as e:
                logger.error("Exception in %s: %r", inner_func.__name__, e, exc_info=True)
                raise
            finally:
                logger.debug("Exiting %s", inner_func.__name__)
        return wrapper

    return decorator(func) if func else decorator
