import logging
import json
from datetime import datetime, timezone

__all__ = ["JSONFormatter"]

class JSONFormatter(logging.Formatter):
    """Custom JSON log formatter with explicit UTC timestamps."""
    def format(self, record):
        log_record = {
            "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if hasattr(record, "username"):
            log_record["username"] = record.username
        if record.exc_info:
            log_record["exception"] = self.formatException(record.exc_info)
        return json.dumps(log_record)
