import logging
import os
import time
from datetime import datetime, timezone

from .formatters import JSONFormatter

__all__ = [
    "get_logger",
    "set_default_app_name",
    "get_default_app_name",
    "set_default_log_dir",
    "get_default_log_dir",
    "UserLoggerAdapter",
]

# --- Globals ---
_default_app_name = "default"
_default_log_dir = os.getenv("LOG_BASE_DIR", os.path.join(".", "logs"))


def set_default_app_name(app_name: str):
    """Set a global default app name for all decorators and loggers."""
    global _default_app_name
    _default_app_name = app_name


def get_default_app_name() -> str:
    return _default_app_name


def set_default_log_dir(path: str):
    """Set a global default log directory base (overrides env var)."""
    global _default_log_dir
    _default_log_dir = path


def get_default_log_dir() -> str:
    """Get the current global default log directory base."""
    return _default_log_dir


class UserLoggerAdapter(logging.LoggerAdapter):
    """Inject username into log records if provided."""

    def process(self, msg, kwargs):
        extra = kwargs.get("extra", {})
        kwargs["extra"] = {**self.extra, **extra}
        return msg, kwargs


def get_logger(
    name: str,
    app_name: str | None = None,
    use_json: bool = True,
    username: str | None = None,
) -> logging.LoggerAdapter:
    """
    Return a logger with consistent configuration.

    - Logs stored under <base_dir>/<app_name>/<YYYY-MM>/<app_name>-<YYYY-MM-DD>.log
    - Base dir can be overridden via LOG_BASE_DIR env var or set_default_log_dir()
    - All timestamps in UTC
    - JSON by default for EFK
    """
    # Fallback to global default if not passed explicitly
    if app_name is None:
        app_name = get_default_app_name()

    # --- Ensure directory path is UTC-based by month ---
    utc_today = datetime.now(timezone.utc).date()
    log_dir = os.path.join(get_default_log_dir(), app_name, utc_today.strftime("%Y-%m"))
    os.makedirs(log_dir, exist_ok=True)

    # --- Daily log file (UTC) ---
    log_filename = f"{app_name}-{utc_today.strftime('%Y-%m-%d')}.log"
    log_path = os.path.join(log_dir, log_filename)

    logger = logging.getLogger(name)

    # --- Only add a FileHandler if none exists for this file ---
    if not any(
        isinstance(h, logging.FileHandler) and getattr(h, "baseFilename", None) == os.path.abspath(log_path)
        for h in logger.handlers
    ):
        handler = logging.FileHandler(log_path, mode="a", encoding="utf-8")

        if use_json:
            handler.setFormatter(JSONFormatter())
        else:
            formatter = logging.Formatter(
                "%(asctime)s - %(levelname)s - %(name)s - [%(username)s] - %(message)s"
            )
            formatter.converter = time.gmtime  # ✅ Force UTC in plain text
            handler.setFormatter(formatter)

        logger.addHandler(handler)
        logger.setLevel(logging.DEBUG)

    # --- Always return wrapped logger with username (default "-") ---
    return UserLoggerAdapter(logger, {"username": username or "-"})
