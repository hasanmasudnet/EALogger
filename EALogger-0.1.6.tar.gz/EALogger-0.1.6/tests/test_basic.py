import json
import re
from pathlib import Path
from datetime import datetime, timezone

from alanlogger import get_logger, log_entry_exit


def _read_last_line(p: Path) -> str:
    with p.open("r", encoding="utf-8") as fh:
        lines = fh.readlines()
    return lines[-1].strip() if lines else ""


def test_json_logger_writes_utc_and_username(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)

    logger = get_logger(__name__, app_name="testapp", use_json=True, username="ian")
    logger.info("hello world")

    # --- Verify UTC-based paths ---
    utc_today = datetime.now(timezone.utc).date()
    ym = utc_today.strftime("%Y-%m")
    d = utc_today.strftime("%Y-%m-%d")

    app_dir = tmp_path / "logs" / "testapp" / ym
    logfile = app_dir / f"testapp-{d}.log"
    assert logfile.exists(), f"Expected logfile {logfile} to exist"

    data = json.loads(_read_last_line(logfile))
    assert data["level"] == "INFO"
    assert data["logger"] == __name__
    assert data["message"] == "hello world"
    assert data.get("username") == "ian"
    assert re.match(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d+Z$", data["timestamp"])


def test_decorator_creates_default_logs(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)

    @log_entry_exit
    def add(a, b):
        return a + b

    assert add(2, 3) == 5

    # --- Verify UTC-based paths ---
    utc_today = datetime.now(timezone.utc).date()
    ym = utc_today.strftime("%Y-%m")
    d = utc_today.strftime("%Y-%m-%d")

    default_dir = tmp_path / "logs" / "default" / ym
    logfile = default_dir / f"default-{d}.log"
    assert logfile.exists(), f"Expected logfile {logfile} to exist"

    # Parse JSON lines
    lines = logfile.read_text(encoding="utf-8").splitlines()
    data = [json.loads(line) for line in lines]

    # ✅ Entry/exit messages exist
    assert any("Entering add" in d["message"] for d in data)
    assert any("Exiting add" in d["message"] for d in data)

    # ✅ Username field is "-" since decorator doesn’t pass one
    assert all(d["username"] == "-" for d in data)


def test_plain_vs_json_consistency(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)

    utc_today = datetime.now(timezone.utc).date()
    ym = utc_today.strftime("%Y-%m")
    d = utc_today.strftime("%Y-%m-%d")

    # --- JSON logger ---
    json_logger = get_logger("jsonmod", app_name="combo", use_json=True, username="alice")
    json_logger.info("hello json")

    combo_dir = tmp_path / "logs" / "combo" / ym
    logfile = combo_dir / f"combo-{d}.log"
    assert logfile.exists()

    json_data = json.loads(_read_last_line(logfile))
    assert json_data["message"] == "hello json"
    assert json_data["username"] == "alice"

    # --- Plain-text logger ---
    plain_logger = get_logger("plainmod", app_name="combo", use_json=False, username="bob")
    plain_logger.info("hello plain")

    contents = logfile.read_text(encoding="utf-8")
    # ✅ Plain-text entry shows [bob]
    assert "[bob]" in contents
    assert "hello plain" in contents
